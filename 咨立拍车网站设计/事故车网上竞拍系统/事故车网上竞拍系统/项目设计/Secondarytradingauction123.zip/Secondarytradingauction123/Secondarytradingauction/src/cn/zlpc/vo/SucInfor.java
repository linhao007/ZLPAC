package cn.zlpc.vo;

public class SucInfor{
	private Integer v_id;
	private String plateNo;
	private String tname;
	private String vname;
	private String tel;
	private Integer price;


	public Integer getV_id() {
		return v_id;
	}

	public void setV_id(Integer v_id) {
		this.v_id = v_id;
	}

	public String getPlateNo() {
		return plateNo;
	}

	public void setPlateNo(String plateNo) {
		this.plateNo = plateNo;
	}

	public String getTname() {
		 return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getVname() {
		 return this.vname;
	}

	public void setVname(String vname) {
		this.vname = vname;
	}

	public String getTel() {
		 return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public Integer getPrice() {
		 return this.price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

}