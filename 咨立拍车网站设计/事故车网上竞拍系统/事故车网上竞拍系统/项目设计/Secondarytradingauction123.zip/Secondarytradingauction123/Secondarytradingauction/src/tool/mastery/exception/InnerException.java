package tool.mastery.exception;

@SuppressWarnings("serial")
public class InnerException extends RuntimeException{

	public InnerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InnerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
