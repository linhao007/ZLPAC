package tool.mastery.exception;

@SuppressWarnings("serial")
public class DBException extends Exception {

	public DBException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DBException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
