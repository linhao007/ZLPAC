package cn.zlpc.service;

/**
 * 用于当是多个po时的Service，将其拆分成单个po后处理单个po的操作，并且需要对其中的数据进行处理
 * @author mastery
 *
 */
public class MultiService {

}
