$(document).ready(function(){
	$("form").validate({});
});