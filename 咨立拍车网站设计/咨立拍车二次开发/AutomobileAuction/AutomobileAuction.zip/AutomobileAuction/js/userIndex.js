/**
 * Created by think on 2014/11/7.
 */
$(document).ready(function(){

    TopNavigateBar.update(username);

    LeftSideBarNavigate.initNavigate();
});