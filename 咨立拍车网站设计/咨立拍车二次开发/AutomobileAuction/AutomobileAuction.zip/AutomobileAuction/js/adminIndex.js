/**
 * Created with IntelliJ IDEA.
 * User: yifan
 * Date: 14-11-10
 * Time: 下午1:17
 * To change this template use File | Settings | File Templates.
 */
$(document).ready(function(){
    TopNavigateBar.update(username);
    LeftSideBarNavigate.initNavigate();
});