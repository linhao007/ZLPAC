//顺序导航栏
var target = {
                "register":{url:"register.jsp",text:"会员中心",type:"navigate",pos:2},
                "logout":{url:"logout.action",text:"会员中心",type:"navigate",pos:0},
				"index":{url:"first.action",text:"欢迎光临咨立拍汽车拍卖",type:"welcome",pos:0},
			 	"sales":{url:"sales.action",text:"网络拍卖",type:"navigate",pos:1},
                "detail":{url:"detail.action",text:"网络拍卖",type:"navigate",pos:1},
				"user":{url:"tryLogin.action",text:"会员中心",type:"navigate",pos:2},
                "login":{url:"login.action",text:"会员中心",type:"navigate",pos:2},
				"auction":{url:"sales.action",text:"拍卖预告",type:"navigate",pos:3},
				"help":{url:"help.html",text:"帮助中心",type:"navigate",pos:4},
				"latest":{url:"latest.html",text:"业界风向",type:"navigate",pos:5}
			 };